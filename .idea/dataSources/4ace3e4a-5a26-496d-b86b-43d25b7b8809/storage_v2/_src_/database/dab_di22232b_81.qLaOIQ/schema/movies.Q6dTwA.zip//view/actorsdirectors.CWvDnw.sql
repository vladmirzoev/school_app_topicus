create view actorsdirectors(pid, name) as
SELECT DISTINCT a.pid,
                person.name
FROM movies.acts a,
     movies.directs b
         JOIN movies.person USING (pid)
WHERE a.pid = b.pid
  AND a.mid = b.mid;

alter table actorsdirectors
    owner to dab_di22232b_81;

