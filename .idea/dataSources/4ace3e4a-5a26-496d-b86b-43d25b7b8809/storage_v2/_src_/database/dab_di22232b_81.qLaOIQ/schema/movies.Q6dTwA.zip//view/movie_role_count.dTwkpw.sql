create view movie_role_count(mid, name, year, plot_outline, rating, count) as
SELECT a.mid,
       a.name,
       a.year,
       a.plot_outline,
       a.rating,
       count(b.role) AS count
FROM movies.movie a
         JOIN movies.acts b USING (mid)
GROUP BY a.mid;

alter table movie_role_count
    owner to dab_di22232b_81;

