create function screenwritersofactor(actor text) returns SETOF text
    language plpgsql
as
$$BEGIN
RETURN QUERY
SELECT DISTINCT c.name FROM (
SELECT a.mid FROM movies.movie a, movies.acts b, movies.person c
WHERE a.mid = b.mid AND b.pid = c.pid AND c.name LIKE actor) a, movies.writes b, movies.person c 
WHERE a.mid=b.mid AND b.pid=c.pid;
END;
$$;

alter function screenwritersofactor(text) owner to dab_di22232b_81;

